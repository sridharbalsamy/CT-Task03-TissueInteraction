## only contains detector_geometry 
# this is done as in future we might not need the detector.py after integration except for the geometry
