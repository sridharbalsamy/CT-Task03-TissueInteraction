"""Generate one source-data bundle per CT view.

The tissue-interaction module receives the returned dictionary as a single
object named ``data``. Its ``data_matrix`` columns are
[x, y, z, dx, dy, dz, sampled_energy_keV, photon_weight].
"""
from __future__ import annotations

import numpy as np

try:
    from . import config as default_config
    from .spectrum import generate_spectrum, apply_filtration, sample_photon_energies
    from .geometry import sample_focal_spot, generate_pixel_directions, sample_directions
    from .weights import calculate_photon_weights, apply_bowtie, apply_heel_effect, add_poisson_noise
except ImportError:  # direct execution from this directory
    import config as default_config
    from spectrum import generate_spectrum, apply_filtration, sample_photon_energies
    from geometry import sample_focal_spot, generate_pixel_directions, sample_directions
    from weights import calculate_photon_weights, apply_bowtie, apply_heel_effect, add_poisson_noise


def run_source_simulation(source_pos=None, det_pos=None, detector_pixels=None, cfg=None, rng_seed=0):
    """Return the source output bundle for one view; no flat-field image is made."""
    cfg = cfg or default_config
    if source_pos is None or det_pos is None or detector_pixels is None:
        raise ValueError("source_pos, det_pos, and detector_pixels are required for integrated execution")

    source_pos = np.asarray(source_pos, dtype=float)
    det_pos = np.asarray(det_pos, dtype=float)
    detector_pixels = np.asarray(detector_pixels, dtype=float)
    if source_pos.shape != (3,) or det_pos.shape != (3,):
        raise ValueError("source_pos and det_pos must each have shape (3,)")
    if detector_pixels.ndim != 2 or detector_pixels.shape[1] != 3:
        raise ValueError("detector_pixels must have shape (N, 3)")
    if detector_pixels.shape[0] != int(cfg.N_SAMPLES):
        raise ValueError(
            f"Configured N_SAMPLES={cfg.N_SAMPLES} does not match detector pixel count "
            f"{detector_pixels.shape[0]}"
        )

    rng = np.random.default_rng(rng_seed)
    central_direction = det_pos - source_pos
    central_norm = np.linalg.norm(central_direction)
    if central_norm <= 0:
        raise ValueError("Source and detector positions must differ")
    central_direction /= central_norm
    n_samples = int(cfg.N_SAMPLES)

    energies_grid, intensity_unfiltered = generate_spectrum(
        float(cfg.KVP), float(cfg.E_MIN_KEV), float(cfg.E_STEP_KEV)
    )
    intensity_filtered = apply_filtration(
        energies_grid, intensity_unfiltered, float(cfg.AL_FILTRATION_MM)
    )
    photon_energies = sample_photon_energies(energies_grid, intensity_filtered, n_samples, rng)
    photon_positions = sample_focal_spot(
        source_pos, cfg.FOCAL_SPOT_SIZE, central_direction, n_samples, rng
    )
    photon_directions = generate_pixel_directions(photon_positions, detector_pixels)

    photon_weights = calculate_photon_weights(float(cfg.MA), float(cfg.EXPOSURE_TIME), n_samples)
    photon_weights, bowtie_thickness, bowtie_transmission = apply_bowtie(
        photon_directions, central_direction, photon_energies, photon_weights,
        float(cfg.CONE_ANGLE_DEG), float(cfg.BOWTIE_MIN_THICKNESS_MM),
        float(cfg.BOWTIE_MAX_THICKNESS_MM),
    )
    photon_weights = apply_heel_effect(
        photon_directions, central_direction, photon_weights, float(cfg.ANODE_ANGLE_DEG),
        heel_axis=np.array([1.0, 0.0, 0.0]), enable=bool(cfg.ENABLE_HEEL_EFFECT),
    )
    photon_weights = add_poisson_noise(
        photon_weights, enable=bool(cfg.ENABLE_POISSON_ON_WEIGHTS), rng=rng
    )

    data_matrix = np.column_stack(
        (photon_positions, photon_directions, photon_energies, photon_weights)
    )
    if data_matrix.shape != (n_samples, 8):
        raise ValueError(f"Invalid source data shape: {data_matrix.shape}")
    if not np.all(np.isfinite(data_matrix)) or np.any(photon_weights < 0):
        raise ValueError("Source data contains non-finite values or negative weights")

    # All source information is passed downstream as this single data bundle.
    return {
        "data_matrix": data_matrix,
        "energies_grid": np.asarray(energies_grid, dtype=float),
        "intensity_unfiltered": np.asarray(intensity_unfiltered, dtype=float),
        "intensity_filtered": np.asarray(intensity_filtered, dtype=float),
        "photon_positions": photon_positions,
        "photon_directions": photon_directions,
        "photon_energies": photon_energies,
        "photon_weights": photon_weights,
        "bowtie_thickness": bowtie_thickness,
        "bowtie_transmission": bowtie_transmission,
    }
