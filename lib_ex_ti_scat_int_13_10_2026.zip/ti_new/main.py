"""Run the local source -> tissue -> detector CT pipeline.

Run from this directory:

    python main.py

By default, this processes every view in ``ct_system_output.json``. Use
``--views`` to run a smaller selected subset for testing.
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np

from config import DEFAULT_CONFIG_PATH, get_view, load_config
from cylinder_voxel import create_cylinder_voxel
from detector_geometry import build_rays, generate_detector_pixels
from energy_integrating_detector import EnergyIntegratingDetector
from spectrum import generate_spectrum
from tissue_interaction import tissue_interaction


def write_view_csv(
    output_path: Path,
    view: dict,
    detector_signal_electrons: np.ndarray,
    rays: np.ndarray,
    energies_keV: np.ndarray,
) -> None:
    """Write one energy-integrated detector CSV for one view."""
    rows, channels = detector_signal_electrons.shape
    with output_path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(
            [
                "view_index",
                "angle_deg",
                "table_y_mm",
                "detector_row",
                "detector_channel",
                "ray_origin_x_mm",
                "ray_origin_y_mm",
                "ray_origin_z_mm",
                "ray_direction_x",
                "ray_direction_y",
                "ray_direction_z",
                "energy_bin_count",
                "energy_min_keV",
                "energy_max_keV",
                "detector_signal_electrons_energy_integrated",
            ]
        )
        for ray_index, signal in enumerate(detector_signal_electrons.ravel()):
            row, channel = divmod(ray_index, channels)
            writer.writerow(
                [
                    view["view_index"],
                    view["angle_deg"],
                    view["table_y_mm"],
                    row,
                    channel,
                    *rays[ray_index, :3],
                    *rays[ray_index, 3:],
                    len(energies_keV),
                    energies_keV[0],
                    energies_keV[-1],
                    signal,
                ]
            )


def run_pipeline(
    config_path: str | Path = DEFAULT_CONFIG_PATH,
    output_dir: str | Path = "photon_output",
    view_indices: list[int] | None = None,
    photons_per_ray: float = 1.0,
) -> None:
    """Run selected CT views and write one detector CSV per view."""
    config = load_config(config_path)
    system = config["system_config"]
    detector_config = {
        "detector_rows": 64,
        "detector_channels": 888,
        "detector_element_width_mm": 0.625,
        "detector_element_height_mm": 0.625,
        "detector_width_mm": 555.0,
        "detector_height_mm": 40.0,
        "detector_type": "energy_integrating",
        "detector_material": "scintillator_photodiode",
        "collimation_mm": system["collimation_mm"],
    }
    rows = detector_config["detector_rows"]
    channels = detector_config["detector_channels"]
    voxel_size_mm = 1.0
    _, voxel_material = create_cylinder_voxel(
        radius_mm=25.0,
        height_mm=50.0,
        voxel_size_mm=voxel_size_mm,
        density=1.0,
        material_id=1,
    )
    energies_keV, spectrum = generate_spectrum(system["kvp"])
    detector = EnergyIntegratingDetector(config=detector_config)
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    if view_indices is None:
        view_indices = list(range(len(config["trajectory"]["views"])))
    for view_index in view_indices:
        view = get_view(config, view_index)
        pixels, half_cone_angle_deg, central_direction = generate_detector_pixels(
            view["detector_position_mm"],
            view["source_position_mm"],
            rows,
            channels,
            detector_config["detector_element_width_mm"],
            detector_config["detector_element_height_mm"],
        )
        rays = build_rays(view["source_position_mm"], pixels)
        transmitted = tissue_interaction(
            rays,
            voxel_material,
            voxel_size_mm,
            energies_keV,
            spectrum,
            photons_per_ray=photons_per_ray,
            spectrum_is_density=True,
        )
        fluence = transmitted.reshape(rows, channels, len(energies_keV))
        detector_result = detector.detect(fluence, energies_keV)
        detector_signal = detector_result["measured_signal_electrons"]
        write_view_csv(
            output_path / f"view_{view_index:04d}_detector.csv",
            view,
            detector_signal,
            rays,
            energies_keV,
        )
        np.save(output_path / f"view_{view_index:04d}_detector.npy", detector_signal)
        print(
            f"view={view_index} angle={view['angle_deg']:.6f} deg "
            f"half_cone={half_cone_angle_deg:.6f} deg "
            f"central_direction={central_direction} "
            f"csv={output_path / f'view_{view_index:04d}_detector.csv'}"
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG_PATH)
    parser.add_argument("--output-dir", type=Path, default=Path("photon_output"))
    parser.add_argument(
        "--views",
        type=int,
        nargs="+",
        help="Optional selected view indices; omitted means all configured views",
    )
    parser.add_argument("--photons-per-ray", type=float, default=1.0)
    return parser.parse_args()


if __name__ == "__main__":
    arguments = parse_args()
    loaded = load_config(arguments.config)
    run_pipeline(
        config_path=arguments.config,
        output_dir=arguments.output_dir,
        view_indices=arguments.views,
        photons_per_ray=arguments.photons_per_ray,
    )
