"""Local phase-1 analytical source spectrum."""

from __future__ import annotations

import numpy as np


def generate_spectrum(
    kvp: float,
    *,
    energy_min_keV: float = 1.0,
    energy_step_keV: float = 0.5,
    filter_thickness_mm: float = 1.5,
    target_z: int = 74,
) -> tuple[np.ndarray, np.ndarray]:
    """Return energy bins and an uncalibrated filtered spectral density.

    The spectrum is a shape in arbitrary source units. ``main.py`` normalizes
    it using the explicitly supplied ``photons_per_ray`` calibration.
    """
    if kvp <= energy_min_keV or energy_step_keV <= 0:
        raise ValueError("kvp must exceed energy_min_keV and energy_step_keV must be positive")
    energies = np.arange(energy_min_keV, kvp + energy_step_keV, energy_step_keV)
    bremsstrahlung = target_z * np.maximum(kvp - energies, 0.0) / energies
    filtration = np.exp(-filter_thickness_mm * (25.0 / energies) ** 3)
    return energies, bremsstrahlung * filtration
