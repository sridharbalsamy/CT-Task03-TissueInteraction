"""Material attenuation data used by the phase-1 tissue model.

The attenuation coefficients returned by this module are linear attenuation
coefficients in mm^-1.  xraylib supplies NIST compound data in cm^2/g and
the conversion to mm^-1 is performed here.
"""

from __future__ import annotations

from numbers import Integral, Real

import xraylib


MATERIALS = {
    0: {"name": "Air", "nist_name": "Air, Dry (near sea level)"},
    1: {"name": "Soft Tissue", "nist_name": "Tissue, Soft (ICRP)"},
    2: {"name": "Cortical Bone", "nist_name": "Bone, Cortical (ICRP)"},
    3: {"name": "Lung", "nist_name": "Lung (ICRP)"},
    4: {"name": "Adipose", "nist_name": "Adipose Tissue (ICRP)"},
    5: {"name": "Water", "nist_name": "Water, Liquid"},
    6: {"name": "Skeletal Muscle", "nist_name": "Muscle, Skeletal"},
}


def get_material_info(material_id: int) -> dict[str, str]:
    """Return the configured NIST material record."""
    if not isinstance(material_id, Integral) or int(material_id) not in MATERIALS:
        raise ValueError(f"Unknown material ID: {material_id!r}")
    return MATERIALS[int(material_id)]


def mass_attenuation_coefficient(material_id: int, energy_keV: Real) -> float:
    """Return mass attenuation in cm^2/g for one photon energy in keV."""
    if not isinstance(energy_keV, Real) or float(energy_keV) <= 0:
        raise ValueError("energy_keV must be a positive real number")
    material = get_material_info(material_id)
    return float(xraylib.CS_Total_CP(material["nist_name"], float(energy_keV)))


def material_density(material_id: int) -> float:
    """Return material density in g/cm^3."""
    material = get_material_info(material_id)
    data = xraylib.GetCompoundDataNISTByName(material["nist_name"])
    return float(data["density"])


def linear_attenuation_coefficient(material_id: int, energy_keV: Real) -> float:
    """Return linear attenuation in mm^-1.

    xraylib returns (cm^2/g) * (g/cm^3) = cm^-1.  Dividing by 10 converts
    cm^-1 to mm^-1, matching the voxel and ray path-length units.
    """
    mu_cm_inv = (
        mass_attenuation_coefficient(material_id, energy_keV)
        * material_density(material_id)
    )
    return mu_cm_inv / 10.0
