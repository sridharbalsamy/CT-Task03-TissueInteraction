"""Configuration and view geometry loader for the local ti_new pipeline."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


DEFAULT_CONFIG_PATH = Path(__file__).with_name("ct_system_output.json")


def load_config(path: str | Path = DEFAULT_CONFIG_PATH) -> dict:
    """Load the copied CT system configuration used by this folder."""
    with Path(path).open("r", encoding="utf-8") as file:
        config = json.load(file)
    if "system_config" not in config or "trajectory" not in config:
        raise ValueError("Configuration must contain system_config and trajectory")
    if not config["trajectory"].get("views"):
        raise ValueError("Configuration contains no trajectory views")
    return config


def get_view(config: dict, view_index: int) -> dict:
    """Return one configuration view with validated source/detector vectors."""
    views = config["trajectory"]["views"]
    if not 0 <= view_index < len(views):
        raise IndexError(f"view_index must be between 0 and {len(views) - 1}")
    view = views[view_index]
    source = np.array(
        [view["source"]["x_mm"], view["source"]["y_mm"], view["source"]["z_mm"]],
        dtype=float,
    )
    detector = np.array(
        [view["detector"]["x_mm"], view["detector"]["y_mm"], view["detector"]["z_mm"]],
        dtype=float,
    )
    return {
        "view_index": int(view["view_index"]),
        "angle_deg": float(view["angle_deg"]),
        "table_y_mm": float(view["table_y_mm"]),
        "source_position_mm": source,
        "detector_position_mm": detector,
    }
