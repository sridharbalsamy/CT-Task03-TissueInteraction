"""Phase-1 polychromatic tissue interaction for the CT pipeline.

Input contract
--------------
``rays`` has shape ``(n_rays, 6)`` and stores
``[origin_x, origin_y, origin_z, direction_x, direction_y, direction_z]``.
Coordinates and voxel dimensions are in millimetres.  Directions must be
unit vectors.

``voxel_material`` has shape ``(ny, nz, nx)`` and is indexed as
``voxel_material[y, z, x]``.  This is the layout produced by the existing
``create_cylinder_voxel`` helper.

``energies_keV`` has shape ``(n_energy_bins,)``.  ``spectrum`` is either:

* a spectral density in photons / (ray keV), when ``spectrum_is_density=True``;
* a per-bin fluence in photons / ray / bin, otherwise.

The returned array has shape ``(n_rays, n_energy_bins)`` and units
``photons / ray / energy bin``.  It is directly consumable by the detector
contract ``(detector_rows, detector_channels, n_energy_bins)`` after reshaping.

Phase 1 models only primary photons using Beer-Lambert attenuation.  Scattered
photons are deliberately not added.  ``scatter_model="monte_carlo"`` is
reserved for a future implementation and fails explicitly instead of silently
claiming to simulate scattering.
"""

from __future__ import annotations

from numbers import Real

import numpy as np

try:
    from .material import linear_attenuation_coefficient
except ImportError:
    from material import linear_attenuation_coefficient


def _as_float_array(value: object, name: str, ndim: int | None = None) -> np.ndarray:
    array = np.asarray(value, dtype=float)
    if ndim is not None and array.ndim != ndim:
        raise ValueError(f"{name} must have {ndim} dimensions; got {array.ndim}")
    if not np.all(np.isfinite(array)):
        raise ValueError(f"{name} must contain only finite values")
    return array


def validate_inputs(
    rays: object,
    voxel_material: object,
    voxel_size_mm: Real,
    energies_keV: object,
    spectrum: object,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Validate and normalize the public tissue-interaction inputs."""
    rays_array = _as_float_array(rays, "rays", ndim=2)
    if rays_array.shape[1] != 6:
        raise ValueError("rays must have shape (n_rays, 6)")

    material_array = np.asarray(voxel_material)
    if material_array.ndim != 3:
        raise ValueError("voxel_material must have shape (ny, nz, nx)")
    if not np.issubdtype(material_array.dtype, np.integer):
        raise ValueError("voxel_material must contain integer material IDs")
    if material_array.size == 0:
        raise ValueError("voxel_material must not be empty")

    if not isinstance(voxel_size_mm, Real) or voxel_size_mm <= 0:
        raise ValueError("voxel_size_mm must be a positive real number")

    energies = _as_float_array(energies_keV, "energies_keV", ndim=1)
    if energies.size == 0 or np.any(energies <= 0):
        raise ValueError("energies_keV must contain positive values")
    if np.any(np.diff(energies) <= 0):
        raise ValueError("energies_keV must be strictly increasing")

    spectrum_array = _as_float_array(spectrum, "spectrum", ndim=1)
    if spectrum_array.shape != energies.shape:
        raise ValueError("spectrum and energies_keV must have the same shape")
    if np.any(spectrum_array < 0) or not np.any(spectrum_array > 0):
        raise ValueError("spectrum must be non-negative and contain a positive value")

    directions = rays_array[:, 3:6]
    norms = np.linalg.norm(directions, axis=1)
    if np.any(norms <= 0) or not np.allclose(norms, 1.0, rtol=1e-5, atol=1e-7):
        raise ValueError("ray directions in columns 3:6 must be unit vectors")

    return (
        rays_array,
        material_array.astype(np.int64, copy=False),
        np.asarray(voxel_size_mm, dtype=float),
        energies,
        spectrum_array,
    )


def ray_box_intersection(
    origin: np.ndarray,
    direction: np.ndarray,
    box_min: np.ndarray,
    box_max: np.ndarray,
) -> tuple[float, float] | None:
    """Return ray parameters at the box entry and exit, or ``None``."""
    t_min = -np.inf
    t_max = np.inf
    for axis in range(3):
        if abs(direction[axis]) < 1e-12:
            if origin[axis] < box_min[axis] or origin[axis] > box_max[axis]:
                return None
            continue
        near = (box_min[axis] - origin[axis]) / direction[axis]
        far = (box_max[axis] - origin[axis]) / direction[axis]
        t_min = max(t_min, min(near, far))
        t_max = min(t_max, max(near, far))
        if t_min > t_max:
            return None
    return float(t_min), float(t_max)


def traverse_ray(
    origin: np.ndarray,
    direction: np.ndarray,
    voxel_material: np.ndarray,
    voxel_size_mm: float,
) -> dict[int, float]:
    """Accumulate path lengths in mm by material ID using voxel traversal."""
    ny, nz, nx = voxel_material.shape
    volume_size = np.array([nx, ny, nz], dtype=float) * voxel_size_mm
    volume_min = -volume_size / 2.0
    volume_max = volume_size / 2.0
    intersection = ray_box_intersection(origin, direction, volume_min, volume_max)
    if intersection is None or intersection[1] < 0:
        return {}

    t_entry, t_exit = intersection
    t = max(t_entry, 0.0)
    point = origin + t * direction
    index = np.floor((point - volume_min) / voxel_size_mm).astype(int)
    index = np.clip(index, [0, 0, 0], [nx - 1, ny - 1, nz - 1])
    ix, iy, iz = (int(index[0]), int(index[1]), int(index[2]))
    steps = np.where(direction >= 0.0, 1, -1)
    next_t = np.full(3, np.inf, dtype=float)
    delta_t = np.full(3, np.inf, dtype=float)
    sizes = (nx, ny, nz)
    for axis, coordinate in enumerate((ix, iy, iz)):
        if direction[axis] != 0.0:
            boundary_index = coordinate + int(steps[axis] > 0)
            boundary = volume_min[axis] + boundary_index * voxel_size_mm
            next_t[axis] = (boundary - origin[axis]) / direction[axis]
            delta_t[axis] = abs(voxel_size_mm / direction[axis])

    lengths: dict[int, float] = {}
    while all(0 <= index_value < sizes[axis] for axis, index_value in enumerate((ix, iy, iz))) and t <= t_exit:
        boundary_t = min(float(np.min(next_t)), t_exit)
        path_length = max(0.0, boundary_t - t)
        material_id = int(voxel_material[iy, iz, ix])
        lengths[material_id] = lengths.get(material_id, 0.0) + path_length
        t = boundary_t
        if t >= t_exit:
            break
        axis = int(np.argmin(next_t))
        if axis == 0:
            ix += int(steps[axis])
        elif axis == 1:
            iy += int(steps[axis])
        else:
            iz += int(steps[axis])
        next_t[axis] += delta_t[axis]
    return lengths


def precompute_mu(material_ids: np.ndarray, energies_keV: np.ndarray) -> dict[int, np.ndarray]:
    """Build a material-to-energy attenuation table in mm^-1."""
    return {
        int(material_id): np.array(
            [linear_attenuation_coefficient(int(material_id), energy) for energy in energies_keV],
            dtype=float,
        )
        for material_id in material_ids
    }


def normalize_spectrum(
    energies_keV: np.ndarray,
    spectrum: np.ndarray,
    photons_per_ray: Real,
    spectrum_is_density: bool,
) -> np.ndarray:
    """Convert a source spectrum to calibrated photons per ray per bin."""
    if not isinstance(photons_per_ray, Real) or photons_per_ray <= 0:
        raise ValueError("photons_per_ray must be a positive real number")
    if spectrum_is_density:
        bin_widths = (
            np.gradient(energies_keV)
            if energies_keV.size > 1
            else np.ones_like(energies_keV)
        )
    else:
        bin_widths = np.ones_like(energies_keV)
    weights = spectrum * bin_widths
    total = float(np.sum(weights))
    if total <= 0:
        raise ValueError("spectrum has zero integrated fluence")
    return weights * (float(photons_per_ray) / total)


def calculate_transmitted_photons(
    material_lengths: dict[int, float],
    energies_keV: np.ndarray,
    incident_photons_per_bin: np.ndarray,
    mu_table: dict[int, np.ndarray],
) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(transmission, transmitted photons/bin)`` for one ray."""
    attenuation = np.zeros_like(energies_keV, dtype=float)
    for material_id, path_length_mm in material_lengths.items():
        attenuation += mu_table[material_id] * path_length_mm
    transmission = np.exp(-attenuation)
    return transmission, incident_photons_per_bin * transmission


def tissue_interaction(
    rays: object,
    voxel_material: object,
    voxel_size_mm: Real,
    energies_keV: object,
    spectrum: object,
    *,
    photons_per_ray: Real = 1.0,
    spectrum_is_density: bool = True,
    scatter_model: str = "none",
) -> np.ndarray:
    """Calculate primary transmitted photons for every ray and energy bin."""
    if scatter_model != "none":
        if scatter_model == "monte_carlo":
            raise NotImplementedError("Monte Carlo scattering is reserved for a future phase")
        raise ValueError("scatter_model must be 'none' or 'monte_carlo'")

    rays_array, material_array, voxel_size, energies, source_spectrum = validate_inputs(
        rays, voxel_material, voxel_size_mm, energies_keV, spectrum
    )
    incident = normalize_spectrum(
        energies, source_spectrum, photons_per_ray, spectrum_is_density
    )
    mu_table = precompute_mu(np.unique(material_array), energies)
    transmitted = np.empty((rays_array.shape[0], energies.size), dtype=float)
    for ray_index, ray in enumerate(rays_array):
        lengths = traverse_ray(ray[:3], ray[3:], material_array, float(voxel_size))
        _, transmitted[ray_index] = calculate_transmitted_photons(
            lengths, energies, incident, mu_table
        )
    return transmitted


def transmission_metadata(
    *,
    photons_per_ray: Real,
    spectrum_is_density: bool,
    scatter_model: str = "none",
) -> dict[str, str | float]:
    """Describe the units and physics assumptions of the returned array."""
    return {
        "output_units": "photons / ray / energy bin",
        "input_spectrum_units": (
            "photons / (ray keV)" if spectrum_is_density else "photons / ray / energy bin"
        ),
        "incident_photons_per_ray": float(photons_per_ray),
        "attenuation_model": "Beer-Lambert primary transmission",
        "scatter_model": scatter_model,
    }
