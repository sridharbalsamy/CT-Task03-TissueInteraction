"""Detector pixel and beam-angle geometry for one CT view."""

from __future__ import annotations

import numpy as np


def generate_detector_pixels(
    detector_position_mm: np.ndarray,
    source_position_mm: np.ndarray,
    rows: int,
    channels: int,
    pixel_width_mm: float,
    pixel_height_mm: float,
) -> tuple[np.ndarray, float, np.ndarray]:
    """Return pixel centers, maximum half cone angle, and central direction.

    The returned pixels are ordered row-major, matching
    ``reshape(rows, channels, energy_bins)``.
    """
    central = detector_position_mm - source_position_mm
    central /= np.linalg.norm(central)
    detector_normal = -central
    row_axis = np.array([0.0, 1.0, 0.0])
    channel_axis = np.cross(row_axis, detector_normal)
    channel_axis /= np.linalg.norm(channel_axis)

    row_coordinates = (np.arange(rows) - (rows - 1) / 2.0) * pixel_height_mm
    channel_coordinates = (np.arange(channels) - (channels - 1) / 2.0) * pixel_width_mm
    channel_grid, row_grid = np.meshgrid(channel_coordinates, row_coordinates, indexing="xy")
    pixels = (
        detector_position_mm
        + channel_grid[..., None] * channel_axis
        + row_grid[..., None] * row_axis
    ).reshape(-1, 3)

    ray_directions = pixels - source_position_mm
    ray_directions /= np.linalg.norm(ray_directions, axis=1, keepdims=True)
    cosine = np.clip(ray_directions @ central, -1.0, 1.0)
    half_cone_angle_deg = float(np.degrees(np.max(np.arccos(cosine))))
    return pixels, half_cone_angle_deg, central


def build_rays(source_position_mm: np.ndarray, detector_pixels_mm: np.ndarray) -> np.ndarray:
    """Build ``(n_rays, 6)`` origin/direction rows for tissue interaction."""
    origins = np.repeat(source_position_mm[None, :], len(detector_pixels_mm), axis=0)
    directions = detector_pixels_mm - origins
    directions /= np.linalg.norm(directions, axis=1, keepdims=True)
    return np.column_stack((origins, directions))
