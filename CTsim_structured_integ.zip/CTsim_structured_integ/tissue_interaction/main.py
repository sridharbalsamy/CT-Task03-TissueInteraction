"""Integrated source -> tissue interaction -> scatter -> energy detector pipeline."""
from __future__ import annotations
import argparse
import csv
import sys
import time
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
PROJECT_ROOT = HERE.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

try:  # package execution: python -m ti_new_13_10_2026.main
    from .config import load_config, get_detector_config, get_total_views, get_view
    from .syncer import generate_detector_pixels
    from .cylinder_voxel import create_cylinder_voxel
    from .tissue_interaction import tissue_interaction
    from .scattering import add_scatter
    # from .energy_integrating_detector import EnergyIntegratingDetector
except ImportError:  # direct execution from this directory
    from config import load_config, get_detector_config, get_total_views, get_view
    from syncer import generate_detector_pixels
    from cylinder_voxel import create_cylinder_voxel
    from tissue_interaction import tissue_interaction
    from scattering import add_scatter
    # from energy_integrating_detector import EnergyIntegratingDetector

from xray_source.config import load_source_config
from xray_source.main import run_source_simulation
from CTdetector.energy_integrating_detector import EnergyIntegratingDetector


DEFAULT_CONFIG = HERE.parent / "system_config" / "ct_system_output.json"


def save_view_rays(view_id, data_matrix, detector_signal, output_dir):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"view_{view_id}_rays.csv"
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["view_id", "ray_id", "x", "y", "z", "dx", "dy", "dz", "energy_keV", "weight", "detector_signal"])
        for ray_id, ray in enumerate(data_matrix):
            writer.writerow([view_id, ray_id, *ray.tolist(), float(detector_signal[ray_id])])
    print(f"Saved: {path}")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--views", type=int, nargs="*", default=None,
                        help="zero-based view indices; defaults to all configured views")
    parser.add_argument("--output-dir", type=Path, default=HERE.parent / "photon_output")
    parser.add_argument("--spr", type=float, default=1.2)
    parser.add_argument("--kernel-size", type=int, default=21)
    args = parser.parse_args(argv)

    config = load_config(args.config)
    detector_config = get_detector_config(config)
    source_cfg = load_source_config(args.config, detector_config)
    detector = EnergyIntegratingDetector(config=detector_config)
    geometry_views = get_total_views(config)
    selected_views = list(range(geometry_views)) if args.views is None else args.views
    if not selected_views:
        raise ValueError("At least one view must be selected")
    if any(v < 0 or v >= geometry_views for v in selected_views):
        raise IndexError(f"View indices must be in [0, {geometry_views - 1}]")

    rows = int(detector_config["detector_rows"])
    channels = int(detector_config["detector_channels"])
    expected_rays = rows * channels
    voxel_size_mm = float(config.get("volume", {}).get("voxel_spacing_mm", [1.0])[0])
    volume_size = config.get("volume", {}).get("physical_size_mm", [50.0, 50.0, 50.0])
    # Keep the current phase-1 cylindrical phantom convention, but derive its size from JSON.
    phantom_height_mm = float(volume_size[0])
    phantom_radius_mm = min(float(volume_size[1]), float(volume_size[2])) / 2.0
    voxel_density, voxel_material = create_cylinder_voxel(
        radius_mm=phantom_radius_mm, height_mm=phantom_height_mm,
        voxel_size_mm=voxel_size_mm, density=1.0, material_id=1,
    )
    print("### CONFIG LOADED ###")
    print(f"Views configured: {geometry_views}; views selected: {selected_views}")
    print(f"Detector grid: {rows} x {channels} = {expected_rays} rays/view")
    print(f"Voxel phantom shape: {voxel_material.shape}")

    for view_index in selected_views:
        view = get_view(config, int(view_index))
        source_pos = view["source_position_mm"]
        detector_pos = view["detector_position_mm"]
        detector_pixels = generate_detector_pixels(
            det_pos=detector_pos, source_pos=source_pos,
            rows=rows, channels=channels,
            w_mm=float(detector_config["detector_element_width_mm"]),
            h_mm=float(detector_config["detector_element_height_mm"]),
        )
        if detector_pixels.shape != (expected_rays, 3):
            raise ValueError(f"Unexpected detector pixel shape {detector_pixels.shape}")

        source_result = run_source_simulation(
            source_pos=source_pos, det_pos=detector_pos,
            detector_pixels=detector_pixels, cfg=source_cfg,
            rng_seed=int(view_index),
        )
        
        #---------------------------------------------------------------------------
        #      TISSUE INTERACTION
        #---------------------------------------------------------------------------
        
        # Pass the complete source output bundle as one object to tissue interaction.
        data = source_result
        data_matrix = data["data_matrix"]
        energies = np.asarray(data["energies_grid"], dtype=float)
        print(f"\n### VIEW {view_index + 1}/{geometry_views} ###")
        print(f"View angle: {view['angle_deg']:.4f} deg; table Y: {view['table_y_mm']:.4f} mm")
        print(f"Source data matrix shape: {data_matrix.shape}")
        if data_matrix.shape != (expected_rays, 8):
            raise ValueError(f"Expected source data matrix {(expected_rays, 8)}, got {data_matrix.shape}")
        if energies.shape != (110,):
            raise ValueError(f"Expected 110 energy bins; got {energies.shape}")

        # pass into the tissue interaction function in the same folder
        transmitted = tissue_interaction(data, voxel_material, voxel_size_mm)
        expected_transmitted = (expected_rays, energies.size)
        if transmitted.shape != expected_transmitted:
            raise ValueError(f"Unexpected transmitted shape {transmitted.shape}; expected {expected_transmitted}")
        print(f"Transmitted fluence shape: {transmitted.shape}")

        # Reshape the transmitted fluence to the expected dimensions
        fluence = transmitted.reshape(rows, channels, energies.size)
        if not np.all(np.isfinite(fluence)) or np.any(fluence < 0):
            raise ValueError("Reshaped primary fluence contains invalid values")
        print(f"Reshaped fluence shape: {fluence.shape}")

        # scatter the fluence using the add_scatter function
        # scattering is done
        scatter_result = add_scatter(fluence, spr=args.spr, kernel_size=args.kernel_size)
        fluence_with_scatter = np.asarray(scatter_result["total_photon_fluence"])
        if fluence_with_scatter.shape != (rows, channels, energies.size):
            raise ValueError(f"Unexpected scatter output shape {fluence_with_scatter.shape}")
        if not np.all(np.isfinite(fluence_with_scatter)) or np.any(fluence_with_scatter < 0):
            raise ValueError("Scatter-inclusive fluence contains invalid values")
        print(f"Scatter fluence shape: {fluence_with_scatter.shape}")


        detector_result = detector.detect(fluence_with_scatter, energies)
        detector_image = np.asarray(detector_result["measured_signal_electrons"])
        if detector_image.shape != (rows, channels):
            raise ValueError(f"Unexpected detector image shape {detector_image.shape}")
        if not np.all(np.isfinite(detector_image)):
            raise ValueError("Detector image contains NaN or Inf")

        
        args.output_dir.mkdir(parents=True, exist_ok=True)
        output_id = view_index + 1
        np.save(args.output_dir / f"view_{output_id}_detector.npy", detector_image)
        if output_id in (1, 2, 3):
            save_view_rays(output_id, data_matrix, detector_image.reshape(-1), args.output_dir)
        print(f"Detector image shape: {detector_image.shape}")
        print(f"Saved: {args.output_dir / f'view_{output_id}_detector.npy'}")
        print(f"Total detector signal: {float(np.sum(detector_image)):.6e}")

    print("\nSelected views completed successfully.")


if __name__ == "__main__":
    main()
